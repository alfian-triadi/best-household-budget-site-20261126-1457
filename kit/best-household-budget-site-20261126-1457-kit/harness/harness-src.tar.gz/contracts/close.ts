// How a bounty closes when it names a close block (contracts/competition.ts Close, the bundle's `close`, and
// contracts/sponsor-proposal.ts ProposalCompetition.close): a quota of `slots` paid places, each paying one amount to
// an entry that passes the gate, and a deadline that is either a real instant ('at') or none ('none'), where the
// bundle's deadline is NO_DEADLINE_AT and the bounty ends when its quota fills.
//
// A leaf: it imports contracts/payout-shapes.ts alone (which imports nothing), so the server, the cli and the web app
// all read it; the web's build cannot load contracts/sponsor-proposal.ts, which imports zod and server modules.

import { placesMostOf, type PlacesKind } from './payout-shapes.ts';

/**
 * The deadline a bounty with no deadline (close.deadline 'none') names: its competition.deadline, the end of its dev
 * phase and the start of its open-ended last phase, all this one instant.
 */
export const NO_DEADLINE_AT = '2100-01-01T00:00:00Z';

/** The most slots a quota close pays (close.quota.slots), and so the most prize rows a proposal may list. */
export const QUOTA_SLOTS_MAX = 1000;

/**
 * The most places a bounty of `kind` pays: its quota's slots when it closes on a quota (`quotaSlots`), else its kind's
 * most (placesMostOf).
 */
export function placesMostWith(kind: PlacesKind, quotaSlots: number | null): number {
  return quotaSlots ?? placesMostOf(kind);
}
